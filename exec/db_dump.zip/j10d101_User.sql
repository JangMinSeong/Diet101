CREATE DATABASE  IF NOT EXISTS `j10d101` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `j10d101`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: j10d101.p.ssafy.io    Database: j10d101
-- ------------------------------------------------------
-- Server version	5.5.5-10.11.7-MariaDB-1:10.11.7+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `User`
--

DROP TABLE IF EXISTS `User`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `User` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `createdAt` datetime(6) DEFAULT NULL,
  `updatedAt` datetime(6) DEFAULT NULL,
  `age` int(11) NOT NULL,
  `calorie` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `height` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `oauthId` varchar(255) DEFAULT NULL,
  `provider` enum('KAKAO','NAVER','GOOGLE') DEFAULT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  `role` enum('ROLE_USER','ROLE_ADMIN') DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `weight` int(11) NOT NULL,
  `activity` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `User`
--

LOCK TABLES `User` WRITE;
/*!40000 ALTER TABLE `User` DISABLE KEYS */;
INSERT INTO `User` VALUES (2,'2024-03-28 00:18:04.560473','2024-04-04 01:41:35.026139',20,1465,'qkrtkfkd159@naver.com','FEMALE',160,'http://k.kakaocdn.net/dn/R0959/btsArft89uM/OrowRvs3gCJrawLJNpJtyK/img_110x110.jpg','3373394319','KAKAO','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJxa3J0a2ZrZDE1OUBuYXZlci5jb20iLCJqdGkiOiJSVEsiLCJleHAiOjUyMjU2NDMyMTk0ODk1fQ.q0ZcOQ1Y7q7PkqgTjwSH_sUgmK_qtiaS7EebcbVjyOw','ROLE_USER','이주미',40,0),(3,'2024-03-31 07:22:03.602674','2024-04-04 02:01:58.008056',0,2177,'hs0765@naver.com',NULL,177,'http://k.kakaocdn.net/dn/8N9Pn/btsoSllnLOR/MP0BiaAmZgs8UB7fuqnLH1/img_110x110.jpg','3379469422','KAKAO','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJoczA3NjVAbmF2ZXIuY29tIiwianRpIjoiUlRLIiwiZXhwIjo1MjI1NjQzMjE5NjExOH0.c70-g7lCaYrfg_uJ5W6R27miBNpRAkKSETFXYGUsr0g','ROLE_USER','장민성',76,0),(5,'2024-03-31 17:45:37.964371','2024-04-03 19:32:55.159332',0,1919,'mikj5@naver.com',NULL,200,'http://k.kakaocdn.net/dn/oqxSI/btsz62p2ka4/AwyYwQerbs0saVucJfA3K1/img_110x110.jpg','3415524116','KAKAO','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJtaWtqNUBuYXZlci5jb20iLCJqdGkiOiJSVEsiLCJleHAiOjUyMjU2NDMyMTcyNzc1fQ.sTGcqEwdBqJhX2h4yGoMRQ48_8hFNKf1K10y-LgZqRs','ROLE_USER','이주미',50,1),(6,'2024-03-31 09:33:53.557061','2024-04-04 04:01:29.563591',27,2690,'visualstudio@kakao.com','MALE',170,'https://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640','3405948325','KAKAO','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ2aXN1YWxzdHVkaW9Aa2FrYW8uY29tIiwianRpIjoiUlRLIiwiZXhwIjo1MjI1NjQzMjIwMzI4OX0.JAG7JTFwoq_bx3iGl46xK34fDZlWK0ZptmIvsGmixiQ','ROLE_USER','조현우',60,3),(7,'2024-04-01 09:28:37.592905','2024-04-04 02:03:56.303513',0,2769,'kimbo3212@naver.com',NULL,177,'http://k.kakaocdn.net/dn/bJpwVA/btsFCzPEfpj/qDmuS0PkPXNcYl6fTa9zO0/img_110x110.jpg','3416292488','KAKAO','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJraW1ibzMyMTJAbmF2ZXIuY29tIiwianRpIjoiUlRLIiwiZXhwIjo1MjI1NjQzMjE5NjIzNn0.jAdsupbgxtZ1k5o-ZU8DaaTyJQSIA69TshTDVzl-1bw','ROLE_USER','보근',90,1),(8,'2024-04-03 03:26:05.885908','2024-04-03 09:18:58.984931',24,1537,'shonee99@naver.com','FEMALE',156,'https://k.kakaocdn.net/dn/M6FL9/btsyeqx1QBr/KOSh2icXWHBtcKpWZAJ54k/img_640x640.jpg','3419802804','KAKAO','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJzaG9uZWU5OUBuYXZlci5jb20iLCJqdGkiOiJSVEsiLCJleHAiOjUyMjU2NDMyMTM1OTM4fQ.N0sjmH0tpUYbilOcJTm-Ica2kOlQq_p6c0HvUBqUhfk','ROLE_USER','현수연',47,0),(10,'2024-04-03 05:38:44.820559','2024-04-04 03:21:10.912822',30,5867,'doyokim75@gmail.com','MALE',180,'https://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640','3408103119','KAKAO','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJkb3lva2ltNzVAZ21haWwuY29tIiwianRpIjoiUlRLIiwiZXhwIjo1MjI1NjQzMjIwMDg3MH0.VJclHI2-hwE8eB03CNHayknjv9enfujHMzuDW0efKy4','ROLE_USER','김동영',300,0),(11,'2024-04-03 10:24:03.297525','2024-04-03 10:28:48.020002',20,2310,'tlp1234@naver.com','MALE',171,'https://t1.kakaocdn.net/account_images/default_profile.jpeg.twg.thumb.R640x640','3420441439','KAKAO','eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ0bHAxMjM0QG5hdmVyLmNvbSIsImp0aSI6IlJUSyIsImV4cCI6NTIyNTY0MzIxNDAxMjh9.v4Zw9Cd20fQbt69XkSzACm22QSkSo_NO-pAHFs4zGIA','ROLE_USER','조현준',65,1);
/*!40000 ALTER TABLE `User` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-04 15:16:47
